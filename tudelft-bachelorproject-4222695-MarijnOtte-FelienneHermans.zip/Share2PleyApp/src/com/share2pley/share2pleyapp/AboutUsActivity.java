package com.share2pley.share2pleyapp;

import android.app.Activity;
import android.os.Bundle;

public class AboutUsActivity extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about);
	}
}
