/** Automatically generated file. DO NOT MODIFY */
package com.share2pley.share2pleyapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}