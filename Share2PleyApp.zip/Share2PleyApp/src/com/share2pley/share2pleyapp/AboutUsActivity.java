package com.share2pley.share2pleyapp;

import android.app.Activity;
import android.os.Bundle;

/**
 * 
 * @author Richard Vink - 4233867
 * 
 */
public class AboutUsActivity extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about);
	}
}