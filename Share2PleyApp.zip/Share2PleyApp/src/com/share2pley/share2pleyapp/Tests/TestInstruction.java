package com.share2pley.share2pleyapp.Tests;

import junit.framework.TestSuite;

/**
 * 
 * @author Marijn Otte - ?
 * 
 */
public class TestInstruction extends TestSuite {
	/*
	 * Instruction instruction = new Instruction("Yellow",10);
	 * 
	 * @Test public void testInstruction() {
	 * assertEquals(instruction.getAmount(),10);
	 * assertEquals(instruction.getColor(), "Yellow");
	 * 
	 * instruction.setAmount(12);
	 * 
	 * assertEquals(instruction.getAmount(),12);
	 * 
	 * assertEquals(instruction.toString(),
	 * "Put 12 Yellow\n pieces in the bag");
	 * 
	 * assertEquals(instruction.setForeGround("Pink"), 0xFF106097);
	 * assertEquals(instruction.setForeGround("Red"), 0xFFff0000);
	 * 
	 * assertEquals(instruction.setBackGround("Yellow"),0xFF000000);
	 * assertEquals(instruction.setBackGround("Red"),0xFFFFFFFF); }
	 */

}
