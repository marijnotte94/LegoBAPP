package com.share2pley.share2pleyapp.Tests;

import junit.framework.TestSuite;

/**
 * 
 * @author Marijn Otte - ?
 * 
 */
public class TestSet extends TestSuite {
	/*
	 * Set set = new Set(5,12,33,55,22,11,12, 5, 18);
	 * 
	 * 
	 * @Test public void Test() { assertEquals(set.hasNext(4), true);
	 * assertEquals(set.hasPrevious(0),false); assertEquals(set.hasPrevious(1),
	 * true); for(int i = 0; i<set.getIntructions().size()-1; i++){
	 * assertTrue(set.getInstruction(i).getAmount() <= 10); }
	 * 
	 * 
	 * }
	 */
}
